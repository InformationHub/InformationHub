/* ------- fast.c ------- */

void fasttest(void);

main()
{
	fasttest();
}

