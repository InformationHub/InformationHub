/* AquariusOS Unix Kernel
 * GPLv2 License
 */
#ifndef GDT
#define GDT

#include <stdint.h>

class GDT {
public:

struct GDT;

void encodeGDTEntry(uint8_t *target, struct GDT source);

};

#endif
