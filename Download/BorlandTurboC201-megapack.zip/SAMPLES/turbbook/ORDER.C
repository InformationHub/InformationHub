/* ----- order.c ------ */

#include "twindow.h"
void ordent(void);

main()
{
	load_help("tcprogs.hlp");
	ordent();
}


