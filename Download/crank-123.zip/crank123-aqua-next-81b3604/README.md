aqua-next
=========

The next generation of AquariusOS
---------------------------

  This project aims to re-write AquariusOS. The point of this is so now we won't
have to read 10s of thousands of lines of code that was written by a different
team to find out how it works. This way we know how and when each feature was
implemented.

|        Changes Log of Aqua-next        |
------------------------------------------------

  Version 0.0.5 (Unreleased) [Planned Changes]

  * ELF support
  * EXT2 Filesystem Support
  * CLI (Command Line Interface)

<table>
<tr>
<th>OS</th><th>Lines of code</th><th>ELF Support</th><th>FAT12 Support</th><th>EXT2 Support</th><th>VGA Support</th><th>Keyboard Support</th><th>Protected Mode</th><th>Default Bootloader</th><th>Multiboot Compliant</th><th>Langueges Written In</th>
</tr>
<tr>
<th>Mikestrip</th><th>9095</th><th>No</th><th>Yes</th><th>No</th><th>Yes</th><th>Yes</th><th>No</th><th>MikeOS FAT12 Bootloader</th><th>No</th><th>FASM</th>
</tr>
<tr>
<th>Aqua-next</th><th>336</th><th>No (Not yet)</th><th>No</th><th>No (Not yet)</th><th>Yes</th><th>Almost</th><th>Yes</th><th>GRUB2</th><th>Yes</th><th>C\C++ & GAS</th>
</tr>
<tr>
<th>Linux 4.1</th><th>19.5 Million</th><th>Yes</th><th>Yes</th><th>Yes</th><th>Yes</th><th>Yes</th><th>Yes</th><th>None</th><th>Yes</th><th>C & Gas</th>
</tr>
</table>
