# TachyonOS
A MikeOS-based operating system project that aims to rewrite internals and integrate a lot of new programs and features while maintaining binary compatibility.
