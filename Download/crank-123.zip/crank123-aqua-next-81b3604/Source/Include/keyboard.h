/* Aquarius OS GPLv2 - See Docs/GPLv2
 *
 *    keyboard.c
 *
 * This provides basic keyboard function
 * to Aquarius OS.
 */
#ifndef KBD_H
#define KBD_H

#include <stdint.h>

class KBD {
	public:
	
	unsigned char KBD_KEYS[0x7E];
	
	char getScancode();
	
	char getChar();
}

#endif
