/* ------ prom.c ------ */

void promote(void);

main()
{
	promote();
}


