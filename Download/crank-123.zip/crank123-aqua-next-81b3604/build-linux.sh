#!/bin/sh

# This script compiles the Aquarius OS kernel.

# Aquarius OS utilizes GRUB 2.

echo ">>> Compiling AquariusOS kernel..."

cd Source

i686-elf-as boot.s -o boot.o || exit
i686-elf-gcc -c kernel.c vga.c -std=gnu99 -ffreestanding -O2 -Wall -Wextra || exit
i686-elf-gcc -T linker.ld -o kernel.bin -ffreestanding -O2 -nostdlib boot.o kernel.o vga.o -lgcc || exit
cd ..

echo '>>> Done!'


